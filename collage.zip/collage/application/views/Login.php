<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>registration form </title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
	<style>
		body{
	color: #fff;
	background: #63738a;
	font-family: 'Roboto', sans-serif;
}
.container{
	width: 600px;

}
.form-label{
	color: blue;
}
.container h2 {
	color: #fff;
	margin: 0 0 15px;
	position: relative;
	text-align: center;
}
.container h2:before, .container h2:after {
	content: "";
	height: 2px;
	width: 30%;
	background: #d4d4d4;
	position: absolute;
	top: 50%;
	z-index: 2;
}	
.container h2:before {
	left: 0;
}
.container h2:after {
	right: 0;
}
.container .hint-text {
	color: #fff;
	margin-bottom: 30px;
	text-align: center;
}
.form-control{
	font-size: 15px;
}
.container form {
	color: #999;
	border-radius: 10px;
	margin-bottom: 15px;
	background: #f2f3f7;
	box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
	padding: 30px;
}
.container a{
  color: #fff;
	text-decoration: underline;
}
.container a:hover {
	text-decoration: none;
  color: blue;
}
.new_pppp{
	color: black;
}

	</style>
  </head>
  <body>
 <div class="container mt-3">
 <h2>Login Form</h2>

 <form action="<?php base_url().'login_c'?>" method="post">
  <!--success message -->
<?php if($this->session->flashdata('success')){?>
<p style="color:green"><?php  echo $this->session->flashdata('success');?></p>	
<?php } ?>

<!--error message -->
<?php if($this->session->flashdata('error')){?>
<p style="color:red"><?php  echo $this->session->flashdata('error');?></p>	
<?php } ?>
  <div class="mb-3">
    <label class="form-label">Email:</label>
    <input type="email" class="form-control" name="email" value="<?= set_value('email') ?>"   placeholder="Enter Your Email"> 
	<?php echo form_error('email',"<div style='color:red'>","</div>");?>  

  </div>

  <div class="mb-3">
    <label class="form-label">Password:</label>
    <input type="password" class="form-control" name="password" value="<?= set_value('password') ?>" placeholder="Enter Your Address" >
	<?php echo form_error('password',"<div style='color:red'>","</div>");?>  

  </div>


  <button type="submit" class="btn btn-primary">Login</button>    

</form>
<div class="text-center"><a href="<?php echo site_url('SignUp');?>">Registertion</a></div>


 </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.min.js" integrity="sha384-Rx+T1VzGupg4BHQYs2gCW9It+akI2MM/mndMCy36UVfodzcJcF0GGLxZIzObiEfa" crossorigin="anonymous"></script>
  </body>
</html>