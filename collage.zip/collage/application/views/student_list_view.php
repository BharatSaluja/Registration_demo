<html>    
     <head>
          <title>Student Data View</title>
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <!--link the bootstrap css file-->
          <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
          <script
  src="https://code.jquery.com/jquery-3.7.0.js"
  integrity="sha256-JlqSTELeR4TLqP0OG9dxM7yDPqX1ox/HfgiSLBj8+kM="
  crossorigin="anonymous"></script>
          <link rel="stylesheet" href="//cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
          <style>
               body{
                    background-color: #6c757d;
               }
               .container{
                    /* border: 2px solid gray; */
                    padding-top: 30px;
               
               }


          </style>
     </head>
     <body>

         
          
     <div class="alert alert-success" role="alert">
  you have login successfully</div>
</div>
          <div class="container mb-5">
          <div class="row">
          <div class="col-lg-12 col-sm-12">
               <table class="table table-striped table-hover  table-bordered " id="myTable">
                    <thead class="table">
                         <tr>
                
                              <th>id</th>
                              <th> first Name</th>
                              <th>last Name</th>
                              <th>email</th>
                              <th>D.O.B</th>
                              <th>phonenumber</th>
                              <th>address</th>
                              <th>password</th>
                         </tr>
                    </thead>
                    <tbody>
                         <?php for ($i = 0; $i < count($studentlist); ++$i) { ?>
                              <tr>
                                   <td><?php echo ($i+1); ?></td>
                                   <td><?php echo $studentlist[$i]->firstname; ?></td>
                                   <td><?php echo $studentlist[$i]->lastname; ?></td>
                                   <td><?php echo $studentlist[$i]->email; ?></td>
                                   <td><?php echo $studentlist[$i]->dob; ?></td>
                                   <td><?php echo $studentlist[$i]->phonenumber; ?></td>
                                   <td><?php echo $studentlist[$i]->address; ?></td>
                                   <td><?php echo $studentlist[$i]->password; ?></td>
                              </tr>
                         <?php } ?>
                    </tbody>
               </table>
          </div>   
          </div>
          </div>
     
 

          <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.min.js" integrity="sha384-Rx+T1VzGupg4BHQYs2gCW9It+akI2MM/mndMCy36UVfodzcJcF0GGLxZIzObiEfa" crossorigin="anonymous"></script>
<script src="//cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script>
     $(document).ready (function (){

          let table = new DataTable('#myTable');


     });

     
</script>
     </body>
</html>