<?php 
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class login_c extends CI_Controller{

    public function index(){
         $this->form_validation->set_rules('email','Email id','required|valid_email');
        $this->form_validation->set_rules('password','Password','required|');
        if($this->form_validation->run()){
        $email=$this->input->post('email');
        $password=$this->input->post('password');
        $this->load->model('login_model');
        $validate=$this->login_model->index($email,$password);
        if($validate){
        $this->session->set_userdata('id',$validate->id);	
        $this->session->set_userdata('firstname',$validate->firstName);	
        redirect('student');
        } else {
        $this->session->set_flashdata('error','Invalid login details.Please try again.');
        redirect('login_c');
        }
        } else{
        $this->load->view('Login');	
        }
        }

}

?>