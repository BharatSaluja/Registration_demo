<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class SignUp extends CI_Controller {
public function index()
	{

	    $this->load->library('form_validation');
		$this->form_validation->set_rules('firstname', 'First Name', 'required|alpha|max_length[12]');
		$this->form_validation->set_rules('lastname', 'Last Name', 'required|alpha|max_length[12]');
		$this->form_validation->set_rules('dob', 'D.O.B', 'required');
		$this->form_validation->set_rules('email', 'Email', 'required|valid_email|FILTER_VALIDATE_EMAIL');
		$this->form_validation->set_rules('phonenumber', 'Phone Number', 'required|max_lenght[10]|min_length[10]');
		$this->form_validation->set_rules('address', 'Address', 'required');
		$this->form_validation->set_rules('password', 'Password', 'required|min_length[6]');

		if ($this->form_validation->run() == false) {



			$this->load->view('registration');
		
		}else
		{			
		
			$this->load->model('registertions_model');
			$formArray = array();
			$formArray['firstname'] = $this->input->post('firstname');
			$formArray['lastname'] = $this->input->post('lastname');
			$formArray['dob'] = $this->input->post('dob');
			$formArray['email'] = $this->input->post('email');
			$formArray['phonenumber'] = $this->input->post('phonenumber');
			$formArray['address'] = $this->input->post('address');
			 $formArray ['password'] = password_hash($this->input->post('password'),PASSWORD_DEFAULT);
			$this->registertions_model->register_form($formArray);
			$this->load->view('registration');
		}
	}
	}
    