<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
 class student extends CI_Controller {
     public function __construct()
     {
          parent::__construct();
          $this->load->helper('url');
          $this->load->database();
     }  

     public function index()  
     {
           $this->load->model('student_model');  
           $studentresult = $this->student_model->get_students_list();           
           $data['studentlist'] = $studentresult;
           $this->load->view('student_list_view',$data);
     }
}
