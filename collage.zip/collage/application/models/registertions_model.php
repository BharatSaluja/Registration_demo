<?php 
class registertions_model extends CI_Model {

    public function register_form($formArray){

         $this->db->where('email', $formArray['email']);
        $query = $this->db->get('registration');

        if($query->num_rows() > 0 ){
                    $this->session->set_flashdata( 'error','Email is already exist');
                    redirect(base_url());
       }
       
       else{
        $query= $this->db->insert('registration', $formArray);
        $this->load->model("registertions_model");
        if($query){
            $this->session->set_flashdata('success','Registration successfull, Now you can login.');	
            redirect(base_url());
           
            
           
            } else {
          
                $this->session->set_flashdata('error','Something went wrong. Please try again.');	
            redirect(base_url());
   
        }
       }
       

}

 
}


?>