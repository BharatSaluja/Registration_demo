<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class student_model extends CI_Model{
     function __construct()
     {
           parent::__construct();
           
     }
     function get_students_list()
     {
          $sql = 'select * from registration';
          $query = $this->db->query($sql);
          $result = $query->result();
          return $result;
     }
}