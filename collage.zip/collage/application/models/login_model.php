<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class login_model extends CI_Model{
public function index($email,$password){
 
    $query = $this->db->query("select * from registration where email = '".$email."'");

    if($query->num_rows() > 0){
        $row = $query->row();   
        
          $this->session->set_flashdata('success','Login Successfull, Now you can login.'.$row->email.$row->password);	

        if(password_verify($password,$row->password)){
            $this->session->set_flashdata('success','Login Successfull, Now you can login.');	
            redirect('student');
		}
		else{
            $this->session->set_flashdata('error','email and password invail. Please try again.');	
            redirect('login_c');
		}
	
        }else{
            $this->session->set_flashdata('success','No User found');	
        
         }


  

}

}


// $query=$this->db->where($data);
// $login=$this->db->get('registration');
//  if($login!=NULL){
// return $login->row();
//  }  

//  if($query){
//     $this->session->set_flashdata('success','Login Successfull, Now you can login.');	
//     redirect(base_url());
//     } else {
//     $this->session->set_flashdata('error','email and password invail. Please try again.');	
//     redirect(base_url());
//     }






